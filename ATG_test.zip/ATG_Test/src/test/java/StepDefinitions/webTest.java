package StepDefinitions;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

import java.util.Map;

import org.junit.Assert;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.interactions.Actions;

import com.intuit.karate.Runner;


public class webTest {

	public static WebDriver driver;
	BrowserElements BE = new BrowserElements();
	GeneralFunctions GF = new GeneralFunctions();

	@Given("^login to ATG page$")
	public void i_login_to_atg_page() throws Throwable {
		System.setProperty("webdriver.chrome.driver", "./files/chromedriver.exe");
		ChromeOptions options = new ChromeOptions();
		driver = new ChromeDriver(options);
		driver.manage().window().maximize();
		String ATG_url = "https://www.atg.se/";
		driver.get(ATG_url);
		GF.elementAction(driver, BE.AcceptAllCookie_button).click();
		System.out.println("ATG home page Opened");

	}

	@And("^Select Hast and expand All games in left menu$")
	public void select_hast_and_expand_all_games_in_left_menu() throws Throwable {

		GF.elementAction(driver, BE.Hast_link).click();
		GF.elementAction(driver, BE.AllaSpel_link).click();

		System.out.println("User selected Hast and expande all games");

	}

	// Select V4 from all games left menu to ensure test can run every day
	@And("^Select V4$")
	public void select_v4() throws Throwable {
		new Actions(driver).moveToElement(GF.elementAction(driver, BE.v4_link)).click().perform();
		//GF.elementAction(driver, BE.v4_link).click();
		System.out.println("User selected V4");
	}

	@And("^Mark 4 horses on v4:1, Mark 1 horse on v4:2, Mark 2 horses on v4:3, Mark all horses on v4:4$")
	public void mark_4_horses_on_v41_mark_1_horse_on_v42_mark_2_horses_on_v43_mark_all_horses_on_v44()
			throws Throwable {
		// Mark 4 horses on v4:1
		GF.selectCoupon(1, 4, driver);

		// Mark 1 horse on v4:2
		GF.selectCoupon(2, 1, driver);
		
		// Mark 2 horses on v4:3
		GF.selectCoupon(3, 2, driver);
		
		// Mark all horse on v4:4
		//GF.selectCoupon(4, 15, driver);
		GF.elementAction(driver, BE.allCoupon_button(4)).click();	
		
	}

	@When("^I click on Lagg Spel$")
	public void i_click_on_lagg_spel() throws Throwable {
		GF.elementAction(driver, BE.laggSpel_button).click();
		System.out.println("User clicked on Lagg Spel");

	}

	@Then("^Create Account popup should display$")
	public void create_account_popup_should_display() throws Throwable {
		String authenticatePopup=GF.elementAction(driver, BE.skapa_popup_title).getText();
		System.out.println(authenticatePopup);
		Assert.assertEquals(authenticatePopup, "SKAPA KONTO");
	}

	@And("^close the browser$")
	public void close_the_browser() throws Throwable {
		driver.close();
		driver.quit();
		System.out.println("Test completed and Browser closed");
	}
	
	@Given("^call api test from karate$")
    public void call_api_test_from_karate() throws Throwable {
		apiRunner ap = new apiRunner();
		ap.testCallingClasspathFeatureFromJava();
    }
	

}