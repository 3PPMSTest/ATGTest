package StepDefinitions;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class GeneralFunctions {
	BrowserElements BE = new BrowserElements();
	public WebElement elementAction(WebDriver driver, By testElement)
	{
		@SuppressWarnings("deprecation")
		WebDriverWait wait = new WebDriverWait(driver,60);
		wait.until(ExpectedConditions.visibilityOfElementLocated(testElement));
		return driver.findElement(testElement);
	}

	public void jsClick(WebDriver driver, By testElement)
	{
		@SuppressWarnings("deprecation")
		WebDriverWait wait = new WebDriverWait(driver,60);
		wait.until(ExpectedConditions.visibilityOfElementLocated(testElement));
		WebElement element = driver.findElement(testElement);
		JavascriptExecutor executor = (JavascriptExecutor)driver;
		executor.executeScript("arguments[0].click();", element);
	}
	
	public void jsClick(WebDriver driver, WebElement testElement)
	{
		@SuppressWarnings("deprecation")
		WebDriverWait wait = new WebDriverWait(driver,60);
		wait.until(ExpectedConditions.visibilityOf(testElement));
		JavascriptExecutor executor = (JavascriptExecutor)driver;
		executor.executeScript("arguments[0].click();", testElement);
	}
	
	public void selectCoupon(int row, int count, WebDriver driver)
	{
		int i = 0,j=1;
		while(j<=15){
			if(elementAction(driver, BE.coupon_button(row, j)).getAttribute("data-test-scratched").equals("false")) {
				elementAction(driver, BE.coupon_button(row, j)).click();
				i++;
			}j++;
			if (i == count) {break;}
		}
	}
	
	
}
