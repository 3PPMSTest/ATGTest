package StepDefinitions;
import com.intuit.karate.Runner;
import java.util.Map;

import org.junit.Test;

public class apiRunner {

	 @Test
	 public void testCallingClasspathFeatureFromJava() {
		 Map<String, Object> result = Runner.runFeature("Features/Pet_api_test.feature", null, false);
	    }
	
}
