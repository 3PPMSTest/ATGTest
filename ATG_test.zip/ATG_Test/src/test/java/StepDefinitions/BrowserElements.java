package StepDefinitions;

import org.openqa.selenium.By;

public class BrowserElements {
	
	//Accept all cookies
	public By AcceptAllCookie_button = By.xpath("//button[@id='onetrust-accept-btn-handler']");  
	
	//Home Page Left menu elements
	public By Hast_link = By.xpath("//a[@data-test-id='horse-verticals-menu']");  
	public By AllaSpel_link = By.xpath("//div[@data-test-id='horse-left-menu-sub-menu-toggle-allaspel-new']");
	public By v4_link = By.xpath("//a[@data-test-id='horse-left-menu-sub-menu-item-v4']");
	
	//Coupon selection
	public By coupon_button(int leg, int start)
	{
		//Coupon selection based on row and column number
		return By.xpath("//button[@data-test-id='coupon-button-leg-" + leg + "-start-" + start + "']");
	}
	
	public By allCoupon_button(int leg)
	{
		//All Coupon selection based on row number
		return By.xpath("//button[@data-test-id='leg-" + leg + "-toggle-all']");
	}
	
	
	//laggSpel button
	public By laggSpel_button = By.xpath("//button[@data-test-id='play-game-coupon']");
	
	//Authenticate popup
	public By skapa_popup_title = By.xpath("//h4[@data-test-id='auth-modal-title']/span"); 
}
